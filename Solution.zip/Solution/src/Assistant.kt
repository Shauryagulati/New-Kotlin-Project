import java.util.*

class Assistant(val name: String) {

    fun alarm(time: String) = println("Good morning! The time is $time and You need to follow up your schedule")

    fun coffee(coffee: Coffee) = if (coffee.black) {
        println("Your black coffee with ${coffee.spoonsOfSugar} spoons of sugar is ready!")
    } else {
        println("Your coffee with ${coffee.spoonsOfSugar} spoons of sugar is ready!")
    }

    fun waterHeater(temp: Int) = println("The water has been heated to $temp Sir")

    fun books(day: Int) {
        val messageTemplate = "Books for today are: "
        val subjects =  arrayOf("Advanced Probability", "Aptitude", "Data Structures", "Machine Learning", "Mobile Development")

        when (day) {
            Calendar.MONDAY -> println("$messageTemplate ${subjects[0]}, ${subjects[1]}, ${subjects[2]}")
            Calendar.TUESDAY -> println("$messageTemplate ${subjects[1]}, ${subjects[2]}, ${subjects[3]}")
            Calendar.WEDNESDAY -> println("$messageTemplate ${subjects[2]}, ${subjects[3]}")
            Calendar.THURSDAY -> println("$messageTemplate ${subjects[3]}, ${subjects[4]}")
            Calendar.FRIDAY -> println("$messageTemplate ${subjects[4]}, ${subjects[5]}")
            else -> println("Invalid day")
        }
    }

    fun food() {
        val breakfast = mutableListOf("Oats", "Cereals", "Sandwiches", "Idli", "Dosa")
        val lunch =
            mutableListOf("Mushroom DoPyaaza", "Soya Chaap", "Pizza", "Shahi Paneer", "Mashed Potatoes", "Biryani")
        println("Today's breakfast is ${breakfast.random()} and lunch is ${lunch.random()}")
    }

    fun clothes(polo: String, chinos: String) {
        val shirt = mutableListOf("Blue", "Mustard", "Brick Red", "White", "Wine Pink", "Black")
        val jeans = mutableListOf("White", "Grey", "Black")

        if (shirt.contains(polo)) {
            if (jeans.contains(chinos)) {
                println("Outfit for the Day is ready Sir")
            } else {
                println("No Chinos for that color is present")
            }
        } else {
            println("No Polos for that color is there")
        }
    }


}