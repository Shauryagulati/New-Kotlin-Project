import java.util.*

fun main() {

    /* Name of the Assistant */
    val assistant = Assistant("SRG")

    /* Assistant with its name and Greetings */
    println("Hey! My name is ${assistant.name} and I'm your personal assistant")
    println()

    /* Alarm at which you want to wake up */
    assistant.alarm("4:00 AM")
    println()

    /* Coffee intake with sugar and whether te coffee is black or not */
    assistant.coffee(Coffee(0, true))
    println()

    /* Temperature at which the water will be heated to take bath */
    assistant.waterHeater(25)
    println()

    /* It helps to pack the bag according to the day of the week */
    assistant.books(Calendar.getInstance().get(Calendar.DAY_OF_WEEK))
    println()

    /* Decides Random Breakfast and Lunch for You */
    assistant.food()
    println()

    /* Also Gets your clothes ready on the basis of your colour combination provided */
    assistant.clothes("Wine Pink", "White")
    println()
}